# Maurya Smart Cyber Point - Simple Website (Netlify-ready)

This is a ready-to-edit, lightweight HTML website for *Maurya Smart Cyber Point*.
It uses a light + dark mix theme and includes:
- Home (hero)
- About
- Services
- Contact form (opens mail client and supports WhatsApp prefilled message)
- Netlify-ready: upload files to GitHub and connect to Netlify for free hosting.

**Contact email used in the site:** ak5984895@gmail.com
**WhatsApp number used in the site:** +91 7054121860

## How to use
1. Download and unzip this folder.
2. Edit files (`index.html`, `style.css`, `script.js`) in any text editor (VS Code recommended).
3. To publish on GitHub: create a repo and upload files (Add file → Upload files).
4. To publish on Netlify: Sign up with GitHub (or drag & drop the folder on Netlify Sites dashboard).

## Notes
- The contact form opens the user's mail client using the `mailto:` link. For automatic server-side email delivery, integrate a form backend service (Formspree, Netlify Forms, or custom server).
- You can freely edit the text, services, colors, and images as needed.
