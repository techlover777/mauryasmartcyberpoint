// script.js - handles contact form: opens mail client or WhatsApp with prefilled message
const form = document.getElementById('contactForm');
const whatsappNumber = '917054121860'; // country code + number, as requested
const emailTo = 'ak5984895@gmail.com';

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const name = encodeURIComponent(document.getElementById('name').value.trim());
  const phone = encodeURIComponent(document.getElementById('phone').value.trim());
  const message = encodeURIComponent(document.getElementById('message').value.trim());
  const subject = encodeURIComponent('Service Request from Website');
  const bodyLines = [
    'Name: ' + decodeURIComponent(name),
    'Phone: ' + decodeURIComponent(phone),
    'Message: ' + decodeURIComponent(message)
  ];
  const body = encodeURIComponent(bodyLines.join('\n'));

  // Open default mail client with prefilled subject and body
  const mailto = `mailto:${emailTo}?subject=${subject}&body=${body}`;
  window.location.href = mailto;
});

// WhatsApp send link (for Send via WhatsApp button)
const waButton = document.getElementById('whatsappSend');
waButton.addEventListener('click', (e) => {
  e.preventDefault();
  const name = encodeURIComponent(document.getElementById('name').value.trim());
  const phone = encodeURIComponent(document.getElementById('phone').value.trim());
  const message = encodeURIComponent(document.getElementById('message').value.trim());
  const text = encodeURIComponent(`Service request%0AName: ${decodeURIComponent(name)}%0APhone: ${decodeURIComponent(phone)}%0AMessage: ${decodeURIComponent(message)}`);
  const url = `https://wa.me/${whatsappNumber}?text=${text}`;
  window.open(url, '_blank');
});

// Also set the Chat on WhatsApp hero button to the number provided
document.getElementById('whatsappBtn').setAttribute('href', `https://wa.me/${whatsappNumber}`);
